import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: InstanceType<typeof ZAI> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(request: NextRequest) {
  try {
    const { action, text, targetLang } = await request.json();

    if (!action || !text) {
      return NextResponse.json(
        { error: 'Missing required fields: action and text' },
        { status: 400 }
      );
    }

    if (typeof text !== 'string' || text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Text must be a non-empty string' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    if (action === 'summarize') {
      const result = await zai.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content:
              'You are an expert document summarizer. Provide a clear, concise, and well-structured summary of the given text. Use markdown formatting. Preserve key facts, figures, and conclusions. If the text is very long, focus on the most important points. Always respond in the same language as the input text.',
          },
          {
            role: 'user',
            content: `Please summarize the following document text:\n\n${text}`,
          },
        ],
        thinking: { type: 'disabled' },
      });

      const summary =
        result?.choices?.[0]?.message?.content ??
        'Unable to generate summary.';

      return NextResponse.json({ action: 'summarize', summary });
    }

    if (action === 'translate') {
      if (!targetLang) {
        return NextResponse.json(
          { error: 'Missing required field: targetLang' },
          { status: 400 }
        );
      }

      const langNames: Record<string, string> = {
        es: 'Spanish',
        fr: 'French',
        de: 'German',
        zh: 'Chinese (Simplified)',
        ja: 'Japanese',
        ar: 'Arabic',
        pt: 'Portuguese',
        ru: 'Russian',
        ko: 'Korean',
        it: 'Italian',
        nl: 'Dutch',
        hi: 'Hindi',
      };

      const targetLanguageName = langNames[targetLang] || targetLang;

      const result = await zai.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: `You are a professional translator. Translate the given text to ${targetLanguageName}. 
- Maintain the original formatting (paragraphs, lists, headings).
- Preserve any numbers, dates, and proper nouns.
- Provide only the translated text without any explanations or notes.
- If the text contains markdown, preserve the markdown formatting.`,
          },
          {
            role: 'user',
            content: text,
          },
        ],
        thinking: { type: 'disabled' },
      });

      const translatedText =
        result?.choices?.[0]?.message?.content ??
        'Unable to translate text.';

      return NextResponse.json({
        action: 'translate',
        translatedText,
        targetLang,
        targetLanguageName,
      });
    }

    if (action === 'hashtags') {
      const result = await zai.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: 'You are a social media hashtag expert. Given a topic or content text, generate relevant, popular hashtags. Return ONLY a JSON object with three arrays: "trending" (12 hashtags), "niche" (10 hashtags), and "engagement" (8 hashtags). Each hashtag should start with #. Be creative and relevant to maximize engagement. Do not include any explanations, only the JSON.',
          },
          {
            role: 'user',
            content: `Generate hashtags for this content:\n\n${text}`,
          },
        ],
        thinking: { type: 'disabled' },
      });

      let hashtags;
      const raw = result?.choices?.[0]?.message?.content ?? '';
      try {
        const jsonStr = raw.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
        hashtags = JSON.parse(jsonStr);
      } catch {
        // Fallback: parse hashtags from plain text
        const tags = raw.match(/#[\w]+/g) || [];
        hashtags = {
          trending: tags.slice(0, 12),
          niche: tags.slice(12, 22),
          engagement: tags.slice(22, 30),
        };
      }

      return NextResponse.json({ action: 'hashtags', hashtags });
    }

    return NextResponse.json(
      { error: `Unknown action: ${action}. Supported: summarize, translate, hashtags` },
      { status: 400 }
    );
  } catch (error) {
    console.error('AI API Error:', error);
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : 'An unexpected error occurred while processing your request.',
      },
      { status: 500 }
    );
  }
}
