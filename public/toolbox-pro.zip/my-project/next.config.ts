import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Note: "standalone" output is for Docker/self-hosting only.
  // Vercel uses its own build system and ignores this setting, but we remove it to avoid confusion.
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Allow larger payloads for file uploads (PDF, images, etc.)
  experimental: {
    serverActions: {
      bodySizeLimit: "10mb",
    },
  },
};

export default nextConfig;
